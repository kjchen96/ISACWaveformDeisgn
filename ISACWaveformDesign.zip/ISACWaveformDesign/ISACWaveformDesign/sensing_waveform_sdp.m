% File: sensing_waveform_sdp.m
function x_hat1 = sensing_waveform_sdp(M, xc, As, JE0, JkExtend, epsR)
% Lifted SDP with spectral warm-start and penalty scheduling

% Initialization
n = (0:M-1).';
z0 = exp(-1j*pi*(n.^2)/M);  % ZC-like warm start (unit-modulus)
R  = [z0;1]*[z0',1];

rho = 0.01;
Q = zeros(M+1);
Q(1:M,1:M) = eye(M);
Q(M+1,1:M) = -xc';
Q(1:M,M+1) = -xc;
Q(M+1,M+1) = norm(xc)^2;

for a_it = 1:200
    [V,D] = eig((R+R')/2);
    [lam,ord] = sort(real(diag(D)),'descend'); %#ok<ASGLU>
    u = V(:,ord(1));                               % leading eigenvector

    q = trace(JE0*R) / (epsR + sum_cell_sqabs(JkExtend,R)/(2)/(M-1));

    cvx_begin sdp quiet
        variable Rv(M+1,M+1) hermitian semidefinite
        expressions tk(numel(JkExtend))
        for j=1:numel(JkExtend), tk(j) = trace(JkExtend{j}*Rv); end
        maximize( 2*real(conj(q)*trace(JE0*Rv)) ...
                 - (abs(q)^2)*( sum_square_abs(tk) + epsR ) ...
                 + rho*real(trace((u*u')*Rv)) - rho*trace(Rv) )
        subject to
            trace(Q * Rv) == As;
            Rv(M+1,M+1) == 1;
    cvx_end
    R = Rv;

    rho = min(1e6, rho * 1.5);
end

[U,Sv] = eig((R+R')/2); [~,ix] = max(real(diag(Sv)));
x_hat1 = U(1:M,ix); 
x_hat1 = x_hat1 / norm(x_hat1);
end
