% File: comm_only_design.m
function x_hat3 = comm_only_design(Xc, Fc, h_s)
x_hat3 = Xc * (Fc' * h_s);
x_hat3 = x_hat3 / norm(x_hat3);
end
