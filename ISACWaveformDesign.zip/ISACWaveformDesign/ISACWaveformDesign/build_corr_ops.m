% File: build_corr_ops.m
function [J0, Jk, JkExtend, JE0] = build_corr_ops(M)
% Build correlation shift operators and their lifted extensions

J = @(m) diag(ones(M-abs(m),1), m);
lags = -(M-1):(M-1);
S = lags(lags~=0);

J0 = J(0);
Jk = cell(numel(S),1);
JkExtend = cell(numel(S),1);
for i=1:numel(S)
    Jk{i} = J(S(i));
    Temp = zeros(M+1, M+1);
    Temp(1:M,1:M) = Jk{i};
    JkExtend{i} = Temp;
end

JE0 = eye(M+1);
JE0(end,end) = 0;
end
