% File: sum_cell_sqabs.m
function s = sum_cell_sqabs(JkExtend, R)
% Sum of squared absolute linear forms: sum |trace(Jk * R)|^2
L = numel(JkExtend);
vals = zeros(L,1);
for j = 1:L
    vals(j) = trace(JkExtend{j} * R);
end
s = sum(abs(vals).^2);
end
