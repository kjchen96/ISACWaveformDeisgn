% File: plot_autocorrs.m
function plot_autocorrs(ryy1, ryy2, ryy3, ryy4, M)
% Plot |xcorr| in dB with sparse markers (match your style)

Nfull = numel(ryy3);
marker_idx = 1:3:Nfull;
marker_idx = unique([marker_idx, Nfull, 32]); % ensure last and 32 exist if in range

figure; hold on; grid on; box on;
plot(1-M:M-1, db(abs(ryy4)), 'mx-', 'linewidth',1.5,'MarkerIndices',marker_idx);
plot(1-M:M-1, db(abs(ryy3)), '>-',  'linewidth',1.5,'MarkerIndices',marker_idx,'color',[0 0.5 0]);
plot(1-M:M-1, db(abs(ryy2)), 'bs-', 'linewidth',1.5,'MarkerIndices',marker_idx);
plot(1-M:M-1, db(abs(ryy1)), 'ro-', 'linewidth',1.5,'MarkerIndices',marker_idx);
xlabel('Range Bin'); ylabel('Normalized Magnitude (dB)');
legend({'Sensing-only )','Communication-only','Dual-Functional (Existing)','Dual-Functional (Proposed)'});
axis([ -inf inf -inf inf])
end
