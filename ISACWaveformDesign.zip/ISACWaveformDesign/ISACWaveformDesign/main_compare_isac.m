% File: main_compare_isac.m
%% compare ISAC Waveform Methods (modularized)
clear; close all; clc;

%% Basic Settings
Nt = 32;                        % number of transmit antennas  
K  = 4;                         % number of users
M  = 32;                        % length of waveform
P0 = 10;                        % total transmit power: ||Fc||_F^2 + ||fs||_2^2 <= P0
sigma = 1;                      % noise std
Gamma = 8 * ones(1,K);          % SINR thresholds (linear)

%% Channels and steering
theta  = pi/4;                                    % sensing angle
a      = @(Nt,ang) exp(1j * pi * (0:Nt-1).' .* sin(ang));
alpha  = a(Nt, theta);

% Generate user channels (L paths with random AoAs/gains like your script)
L = 5;
[H, Theta, ChannelGain] = gen_user_channels(Nt, K, L);

%% Baseband data (QPSK-like)
Xc = (2*(randi([0,1],M,K)-0.5))/sqrt(2) + 1j*(2*(randi([0,1],M,K)-0.5))/sqrt(2);

%% Sk masks for inter-user interference
Sk = cell(K,1);
for k = 1:K, S = eye(K); S(k,k) = 0; Sk{k} = S; end

%% Stage 1: Power allocation between sensing and communication (SOC program)
maxIter_fs = 50;
[Fc, fs] = opt_fs_fc_socp(alpha, H, P0, Gamma, sigma, K, Nt, Sk, maxIter_fs);

%% Stage 2: Alternating optimization of Fc and per-user phase
Phase_init = ones(K,1);
[Fc, Phase, xc] = alt_optimize_Fc_and_phase(Xc, alpha, H, P0, Gamma, sigma, Sk, Fc, fs, Phase_init);

%% Build correlation operators for sensing SDP
[J0, Jk, JkExtend, JE0] = build_corr_ops(M);

%% Stage 3: Data-dependent sensing waveform via lifted SDP
Ps  = M;
As  = Ps * abs(fs' * alpha)^2;              % target mainlobe energy
epsR = 0.1;                                 % epsilon used in denominator
x_hat1 = sensing_waveform_sdp(M, xc, As, JE0, JkExtend, epsR);

%% Data-independent sensing waveform（Existing Dual-Functional ISAC Waveform）
 SensingWaveform = load('SensingWaveform.mat');  % contains z_hat1
xs  = SensingWaveform.z_hat1 * sqrt(M);
xi = Xc * (Fc' * alpha) +(fs' * alpha) * xs;
xi = xi/norm(xi);
%% Communication-only design (same as your normalization)
h_s = alpha;                       % sensing steering

x_hat3 = comm_only_design(Xc, Fc, h_s);

%% Autocorrelation and plotting
ryy1 = xcorr(x_hat1);
ryy2 = xcorr(xi);
ryy3 = xcorr(x_hat3);
WsNum = load('WsNum.mat');   % contains ryy1 (autocorr for sensing-only)

ryy4 = WsNum.ryy1;                 % from file

plot_autocorrs(ryy1, ryy2, ryy3, ryy4, M);
