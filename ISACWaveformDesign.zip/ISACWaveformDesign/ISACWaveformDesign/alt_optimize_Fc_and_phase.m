% File: alt_optimize_Fc_and_phase.m
function [Fc, Phase, xc] = alt_optimize_Fc_and_phase(Xc, alpha, H, P0, Gamma, sigma, Sk, Fc_init, fs, Phase_init)
% Alternate between CVX update of Fc and Riemannian optimization of per-user phases
% Requires Manopt toolbox for complex circle manifold

Nt = size(H,1); K = size(H,2);
Fc = Fc_init; Phase = Phase_init;

for ii = 1:10
    % ------- Optimize Fc with fixed phases -------
    Z = Xc * diag(Phase);
    Amap = kron(alpha', Z);      % M × (Nt*K)   （注意用 alpha' 更符合 α^H）
    Q = Amap' * Amap;            % (Nt*K) × (Nt*K)
                                   % PSD

    for mm = 1:50
        Fc_pre = Fc.'; fc_pre = Fc_pre(:);
        cvx_begin quiet
            variable Fc_v(Nt,K) complex
            variable Tmp(K,Nt) complex
            variable fc_v(Nt*K,1) complex
            maximize( real( fc_pre' * Q * fc_v ) )
            subject to
                Tmp == Fc_v';
                fc_v == Tmp(:);
                norm([Fc_v(:); fs], 2) <= sqrt(P0);
                for k = 1:K
                    interf_vec = Sk{k} * ((H(:,k)' * Fc_v).');   % Kx1
                    lhs = [interf_vec; H(:,k)'*fs; sigma];
                    real(H(:,k)' * Fc_v(:,k)) >= 0;
                    imag(H(:,k)' * Fc_v(:,k)) == 0;
                    norm(lhs,2) <= (1/sqrt(Gamma(k))) * real( H(:,k)' * Fc_v(:,k) );
                end
        cvx_end
        Fc = Fc_v;
    end

    % ------- Optimize per-user phases on complex circle manifold -------
    B = Xc * diag(Fc' * alpha);
    Q = B' * B;                                      % Hermitian PSD
    Man = complexcirclefactory(K);
    problem.M     = Man;
    problem.cost  = @(z) -0.5 * real(z' * (Q * z));
    problem.egrad = @(z) -(Q * z);

    z0    = Phase;
    Phase = trustregions(problem, z0);
end

xc = Xc * diag(Phase) * Fc' * alpha;
end
