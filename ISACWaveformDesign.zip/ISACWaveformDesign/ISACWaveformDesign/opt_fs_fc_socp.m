% File: opt_fs_fc_socp.m
function [Fc, fs] = opt_fs_fc_socp(alpha, H, P0, Gamma, sigma, K, Nt, Sk, maxIter)
% SOC-based alternating maximization of fs along alpha with SINR constraints

A = alpha * alpha';
fs_prev = 0.0001 * alpha / norm(alpha);
Fc = zeros(Nt,K); fs = fs_prev;

for it = 1:maxIter
    cvx_begin quiet
        variable Fc_v(Nt,K) complex
        variable fs_v(Nt,1) complex
        maximize( real( fs_prev' * A * fs_v) )
        subject to
            norm([Fc_v(:); fs_v], 2) <= sqrt(P0);
            for k = 1:K
                interf_vec = Sk{k} * ((H(:,k)' * Fc_v).');  % Kx1
                lhs = [interf_vec; H(:,k)'*fs_v; sigma];
                real(H(:,k)' * Fc_v(:,k)) >= 0;
                imag(H(:,k)' * Fc_v(:,k)) == 0;
                norm(lhs,2) <= (1/sqrt(Gamma(k))) * real( H(:,k)' * Fc_v(:,k) );
            end
    cvx_end
    fs_prev = fs_v; Fc = Fc_v; fs = fs_v;
end
end
