% File: gen_user_channels.m
function [H, Theta, ChannelGain] = gen_user_channels(Nt, K, L)
% Generate user channels with L paths per user, random AoAs/gains like original

Theta = 2 * rand(K,L) - 1;                                   % normalized spatial freq
ChannelGain = (randn(K,L) + 1j * randn(K,L))/sqrt(2);        % complex gains
H = zeros(Nt,K);
for ll = 1:L
    for kk = 1:K
        H(:,kk) = H(:,kk) + ChannelGain(kk,ll) * ...
            exp(1j * pi * (0:Nt-1).' * Theta(kk,ll)) / sqrt(Nt);
    end
end
end
