%% Sensing Waveform Design
M = 32;                 % length of waveform
%% -------------------- correlation operators --------------------
J = @(m) diag(ones(M-abs(m),1), m);
lags = -(M-1):(M-1);
S = lags(lags~=0);
J0 = J(0);
Jk = cell(numel(S),1); 
JkS = cell(numel(S),1); 
for i=1:numel(S)
    Jk{i}=J(S(i)); 
    JkS{i} = sparse(J(S(i)));
end

%% -------------------- Proposed --------------------
n = (0:M-1).';
z = exp(-1j*pi*1*(n.^2)/M);
R = z*z';   % warm start
rho = 1;                          % initial DC (auto-adapt)
epsR = 1e-6;
for a_it = 1:200
    [V,D] = eig((R+R')/2);
    [lam,ord] = sort(real(diag(D)),'descend');
    u = V(:,ord(1)); 
    q = trace(J0*R) / ( epsR + sum_cell_sqabs(Jk,R) );
    cvx_begin sdp quiet
            variable Rv(M,M) hermitian semidefinite
            expressions tk(numel(Jk))
            for j=1:numel(Jk)
                tk(j) = trace(Jk{j}*Rv);
            end
            maximize( 2*real(conj(q)*trace(J0*Rv)) ...
                     - (abs(q)^2)*( sum_square_abs(tk) + epsR ) ...
                     + rho*real(trace((u*u')*Rv)) - rho*trace(Rv) )
            subject to
                trace(Rv) == M;
     cvx_end
     R = Rv;
   rho = rho*1.5;
   if rho > 5 * 10^9
       rho = 1e9;
   end
end
[U,Sv] = eig((R+R')/2); [~,ix] = max(real(diag(Sv)));
z_hat1 = U(:,ix)/norm(U(:,ix));     


%% -------------------- Comparisons --------------------
[ryy1, ~] = xcorr(z_hat1);
 
Nfull = numel(ryy1);
marker_idx4 = 1:3:Nfull;

if marker_idx4(end) ~= Nfull
    marker_idx4 = [marker_idx4 Nfull]; % 保证最后一个点有
end
marker_idx4 = [marker_idx4, 32];
plot(1-M:M-1,db(abs(ryy1)),'ro-','linewidth',1.5, 'MarkerIndices', marker_idx4); 

%% Other Functions
function s = sum_cell_sqabs(Jk, R)
    s = 0; 
    for ii=1:numel(Jk)
        s = s + abs(trace(Jk{ii}*R))^2;
    end
end